# Voo Livre — Android + AdMob

Projeto Android Studio do jogo Voo Livre, com Google Mobile Ads SDK integrado para monetização.

## Monetização preparada
- Banner adaptativo fixo na parte inferior usando ID oficial de teste.
- Anúncio premiado (Rewarded) ligado ao botão “💰 Resgatar”. Ao concluir o anúncio, o jogador recebe a recompensa dentro do jogo.
- O projeto usa IDs oficiais de TESTE da AdMob durante o desenvolvimento. **Não publique com esses IDs.**

## Antes de publicar
1. Crie/registre o app no AdMob e obtenha o **App ID** e os **IDs dos blocos de anúncios**.
2. Em `app/src/main/AndroidManifest.xml`, substitua o App ID de teste `ca-app-pub-3940256099942544~3347511713`.
3. Em `MainActivity.java`, substitua `TEST_REWARDED_ID` e `TEST_BANNER_ID` pelos seus IDs reais.
4. Teste no aparelho e só depois gere o AAB assinado.

## Observação
As moedas do jogo continuam sendo uma moeda virtual. O botão “Resgatar” foi convertido em uma ação de anúncio premiado para ganhar moedas; ele **não faz saque em dinheiro**.


## AdMob configurado

ID do app AdMob: `ca-app-pub-8969899364653582~4588315913`

ID do Banner: `ca-app-pub-8969899364653582/4952201439`

ID do Recompensado: `ca-app-pub-8969899364653582/8439011147`

O build **DEBUG** usa IDs oficiais de teste do Google para evitar tráfego inválido durante desenvolvimento. O build **RELEASE** usa os IDs reais acima. Antes de publicar, teste a versão release sem clicar nos anúncios reais; a Google recomenda anúncios de teste durante desenvolvimento.
