# Regras específicas do Voo Livre podem ser adicionadas aqui.
