package com.vooivreelivre.game;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.FullScreenContentCallback;

public class MainActivity extends Activity {
    private WebView webView;
    private RewardedAd rewardedAd;

    // Em DEBUG usamos IDs oficiais de teste; em RELEASE usamos seus blocos reais.
    private static final String TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917";
    private static final String TEST_BANNER_ID = "ca-app-pub-3940256099942544/9214589741";
    private static final String RELEASE_REWARDED_ID = BuildConfig.ADMOB_REWARDED_ID;
    private static final String RELEASE_BANNER_ID = BuildConfig.ADMOB_BANNER_ID;

    private String bannerAdUnitId() {
        return BuildConfig.DEBUG ? TEST_BANNER_ID : RELEASE_BANNER_ID;
    }

    private String rewardedAdUnitId() {
        return BuildConfig.DEBUG ? TEST_REWARDED_ID : RELEASE_REWARDED_ID;
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        MobileAds.initialize(this, initializationStatus -> loadRewardedAd());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFEEF7FB);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFFEEF7FB);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setMediaPlaybackRequiresUserGesture(true);

        webView.addJavascriptInterface(new GameBridge(), "AndroidAds");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");

        root.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        AdView banner = new AdView(this);
        banner.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, 360));
        banner.setAdUnitId(bannerAdUnitId());
        root.addView(banner, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        banner.loadAd(new AdRequest.Builder().build());

        setContentView(root);
    }

    private void loadRewardedAd() {
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(this, rewardedAdUnitId(), request, new RewardedAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull RewardedAd ad) {
                rewardedAd = ad;
                rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() {
                        rewardedAd = null;
                        loadRewardedAd();
                    }
                    @Override public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) {
                        rewardedAd = null;
                        loadRewardedAd();
                    }
                });
            }
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError error) {
                rewardedAd = null;
            }
        });
    }

    private void showRewarded() {
        if (rewardedAd == null) {
            runJs("window.admobRewardUnavailable && window.admobRewardUnavailable();");
            loadRewardedAd();
            return;
        }
        rewardedAd.show(this, (RewardItem rewardItem) ->
                runJs("window.admobRewardEarned && window.admobRewardEarned(" + rewardItem.getAmount() + ");"));
    }

    private void runJs(String javascript) {
        if (webView != null) {
            webView.post(() -> webView.evaluateJavascript(javascript, null));
        }
    }

    private class GameBridge {
        @JavascriptInterface
        public void showRewardedAd() {
            runOnUiThread(MainActivity.this::showRewarded);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
